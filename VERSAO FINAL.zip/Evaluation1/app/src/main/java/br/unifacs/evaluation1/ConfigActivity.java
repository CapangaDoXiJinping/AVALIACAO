package br.unifacs.evaluation1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class ConfigActivity extends AppCompatActivity implements View.OnClickListener {
    
    RadioGroup radioGroup, radioGroup3, radioGroup4, radioGroup2;

    RadioButton radioButton2, radioButton3, radioButton4, radioButton5, radioButton6, radioButton7, radioButton8, radioButton12, radioButton9, radioButton10, radioButton11;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);
        Button back1Button = (Button) findViewById(R.id.back1Button);
        back1Button.setOnClickListener(this);
        sharedPreferences = getSharedPreferences("pref", 0);
        int formato = sharedPreferences.getInt("formato", '5');
        editor = sharedPreferences.edit();
        radioGroup = findViewById(R.id.radioGroup);
        radioButton2 =  findViewById(R.id.radioButton2);
        radioButton3 = findViewById(R.id.radioButton3);
        radioButton4 = findViewById(R.id.radioButton4);
        if(formato ==2){
            radioButton2.setChecked(true);
        }else if(formato == 3){
            radioButton3.setChecked(true);
        }else if(formato == 4){
            radioButton4.setChecked(true);
        }
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                if(checkedId == R.id.radioButton2){
                    editor.putInt("formato", 2);
                }else if(checkedId == R.id.radioButton3){
                    editor.putInt("formato", 3);
                }else if(checkedId == R.id.radioButton4){
                    editor.putInt("formato", 4);
                }
                editor.commit();
            }
        });
        int velocidade = sharedPreferences.getInt("velocidade",3);
        editor = sharedPreferences.edit();
        radioGroup3 = findViewById(R.id.radioGroup3);
        radioButton5 =  findViewById(R.id.radioButton5);
        radioButton6 = findViewById(R.id.radioButton6);
        if(velocidade ==1){
            radioButton5.setChecked(true);
        }else if(velocidade == 2){
            radioButton6.setChecked(true);
        }
        radioGroup3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                if(checkedId == R.id.radioButton5){
                    editor.putInt("velocidade", 1);
                }else if(checkedId == R.id.radioButton6) {
                    editor.putInt("velocidade", 2);
                }

                editor.commit();
            }

        });

        int orientacao = sharedPreferences.getInt("orientacao", 5);
        editor = sharedPreferences.edit();
        radioGroup4 = findViewById(R.id.radioGroup4);
        radioButton7 = findViewById(R.id.radioButton7);
        radioButton8 = findViewById(R.id.radioButton8);
        radioButton12 = findViewById(R.id.radioButton12);

        if(orientacao == 1) {
            radioButton7.setChecked(true);
        }  else if (orientacao == 2){
            radioButton8.setChecked(true);
        } else if (orientacao == 3){
            radioButton12.setChecked(true);
        }
        radioGroup4.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                if(checkedId == R.id.radioButton7){
                    editor.putInt("orientacao", 1);
                }else if(checkedId == R.id.radioButton8){
                    editor.putInt("orientacao", 2);
                }else if(checkedId == R.id.radioButton12){
                    editor.putInt("orientacao", 3);
                }
                editor.commit();
            }
        });

        int mapa = sharedPreferences.getInt("mapa", 5);
        editor = sharedPreferences.edit();
        radioGroup2 = findViewById(R.id.radioGroup2);
        radioButton9 = findViewById(R.id.radioButton9);
        radioButton10 = findViewById(R.id.radioButton10);
        radioButton11 = findViewById(R.id.radioButton11);

        if(mapa==1){
            radioButton9.setChecked(true);
        }else if(mapa==2){
            radioButton10.setChecked(true);
        }else if(mapa==3){
            radioButton11.setChecked(true);
        }
        radioGroup2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                if(checkedId == R.id.radioButton9){
                    editor.putInt("mapa", 1);
                }else if(checkedId == R.id.radioButton10){
                    editor.putInt("mapa", 2);
                }else if(checkedId == R.id.radioButton11){
                    editor.putInt("mapa", 3);
                }
                editor.commit();
            }
        });


    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.back1Button:
                Intent i = new Intent(this, MainActivity.class);
                startActivity(i);
                break;
        }

    }

}